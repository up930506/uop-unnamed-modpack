# UoP Unnamed Modpack
Better name coming soon...
## [Mods](docs/mods.md)
## Installation
### Using CurseForge
Download [curseforge.zip](https://github.com/up930506/uop-unnamed-modpack/blob/main/curseforge.zip) and import it into CurseForge:
1. Open CurseForge.
2. Select Minecraft as your game.
3. Click "Create Custom Profile".
4. Import the zip file.
### Building it manually
1. Install [Packwiz](https://packwiz.infra.link).
2. Clone this repo.
3. Run one (or both) of the following commands to export the pack:
```Bash
# For CurseForge
packwiz curseforge export
# For Modrinth
packwiz modrinth export
```
